c.NotebookApp.token = ''
c.NotebookApp.password = ''